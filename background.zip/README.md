# Context menu: Copy Domain

This adds a context menu item to every link that copies the URL Domain
to the clipboard as plain text and as rich HTML.
