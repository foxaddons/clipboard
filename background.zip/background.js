'use strict';

const searchLabelledId = "searchdname";
const searchQuotes = "searchqts";
const searchQuotes2 = "searchqts2";
const searchDomainC = "searchdc";
const searchDomainC2 = "searchdc2";

const searchEFL = "eflname";
const searchEFL2 = "eflname2";
const searchEFLdot = "eflnamedot";
const searchEFLdot2 = "eflnamedot2";

const searchEFname = "efirstname";

const searchEFnameL = "efirstL";


const QuotesToCText = "qtsctxt";
const QuotesToCText2 = "qtsctxt2";


const ReverseString = "revlocalstr";

const RemoveWS = "remspaces";

const DTStrLocal = "localstrdt";



const OpenStr = "ostrlocal";


const copyPhoneNumber = "cphstr";

const FNStrswap = "fnstrswaplocal";



var stringtemp = "";
var CTabURL = "";

//let tabs = browser.tabs.query({currentWindow: true, active: true});


browser.menus.create({
  id: searchLabelledId,
  title: "Search &Domain",
  contexts: ["all"]
});


browser.menus.create({
  id: searchQuotes,
  title: "Search With &Quotes",
  contexts: ["all"]
});



browser.menus.create({
  id: searchQuotes2,
  title: "Search With &Quotes and PH",
  contexts: ["all"]
});


browser.menus.create({
  id: OpenStr,
  title: "Open URLs",
  contexts: ["all"]
});



browser.menus.create({
  id: FNStrswap,
  title: "&Swap First and Last Name",
  contexts: ["all"]
});



browser.menus.create({
  id: DTStrLocal,
  title: "&Change Date Format",
  contexts: ["all"]
});


browser.menus.create({
  id: RemoveWS,
  title: "&Remove Spaces From String CC",
  contexts: ["all"]
});


browser.menus.create({
  id: ReverseString,
  title: "&String Reverse CC",
  contexts: ["all"]
});


browser.menus.create({
  id: QuotesToCText,
  title: "&ClipBoard Text In Quotes",
  contexts: ["all"]
});



browser.menus.create({
  id: QuotesToCText2,
  title: "&Quotes For All Words CC",
  contexts: ["all"]
});



browser.menus.create({
  id: searchDomainC,
  title: "Search &Domain Site With CC",
  contexts: ["link"]
});


browser.menus.create({
  id: searchDomainC2,
  title: "Search &Domain Site With CC Quotes",
  contexts: ["link"]
});



browser.menus.create({
  id: copyPhoneNumber,
  title: "Copy Phone Number",
  contexts: ["link"]
});



browser.menus.create({
  id: searchEFL,
  title: "FirstName.LastName For &Domain Quotes",
  contexts: ["link"]
});


browser.menus.create({
  id: searchEFL2,
  title: "FLastName For &Domain Quotes",
  contexts: ["link"]
});


browser.menus.create({
  id: searchEFLdot,
  title: "F.LastName For &Domain Quotes",
  contexts: ["link"]
});



browser.menus.create({
  id: searchEFnameL,
  title: "FirstName.L For &Domain Quotes",
  contexts: ["link"]
});



browser.menus.create({
  id: searchEFname,
  title: "First Name For &Domain Quotes",
  contexts: ["link"]
});


browser.menus.create({
  id: searchEFLdot2,
  title: "Last Name For &Domain Quotes",
  contexts: ["link"]
});




browser.menus.onClicked.addListener((info, tab) => {
 		
  switch (info.menuItemId)
  {
	case searchLabelledId:
	{
         
          logTabs(tab.url);

          var str =  "https://www.google.com/search?q=" + stringtemp + " " + CTabURL;
  
	  browser.tabs.create({
		  active: true,
		  index: tab.index + 1,
		  url: str
		});
	
      break;
	}

       case searchQuotes:
	{

          var str =  "https://www.google.com/search?q=" + '"' + stringtemp + '"';
  
	  browser.tabs.create({
		  active: true,
		  index: tab.index + 1,
		  url: str
		});
        }
       break;


      case searchQuotes2:
	{

          var str =  "https://www.google.com/search?q=" + '"' + stringtemp + '"' + " Phone Number";
  
	  browser.tabs.create({
		  active: true,
		  index: tab.index + 1,
		  url: str
		});
        }
       break;
	
    
       case OpenStr:
	{

          const res = stringtemp.split(/\r?\n/); 
	  
          if (res.length > 0)
	  {	
		for (let i = 0; i < res.length; i++) 
		{
			if (res[i].trim().length > 0)
			{
	  			browser.tabs.create({
		  			active: true,
		  			index: tab.index + 1,
		  			url: res[i]
					});
			}
		}

	  }
        }
       break;


      case searchDomainC:
	{

          CommonActions(info.linkUrl, tab.index, 0);

        }
       break;


      case searchDomainC2:
	{

          CommonActions(info.linkUrl, tab.index, 1);

        }
       break;


      case searchEFL:
      {

          CommonActions2(info.linkUrl, tab.index, stringtemp.replace(" ", "."));	  

      }
      break;


      case searchEFL2:
      {
         
          var str = stringtemp.substring(0, 1) + GetLastName();

          CommonActions2(info.linkUrl, tab.index, str);
      }
      break;


      case searchEFLdot:
      {
         
          var str = stringtemp.substring(0, 1) + "." + GetLastName();

          CommonActions2(info.linkUrl, tab.index, str);
      }
      break;


      case searchEFnameL:
      {
         
          var str = GetFirstName() + "." + GetLastName().substring(0, 1);

          CommonActions2(info.linkUrl, tab.index, str);
      }
      break;


      case searchEFLdot2:
      {
         
          var str = GetLastName();

          CommonActions2(info.linkUrl, tab.index, str);
      }
      break;


      case searchEFname:
      {
         
          var str = GetFirstName();

          CommonActions2(info.linkUrl, tab.index, str);
      }
      break;


     case copyPhoneNumber:
      {
         try
	 {

 	  navigator.clipboard.writeText(info.linkUrl.replace("tel:", ""));

	}
	catch { }

      }
      break;

			
      case FNStrswap:
      {         

 	  navigator.clipboard.writeText(GetLastName().trim() + " " + GetFirstName().trim());

      }
      break;


      case QuotesToCText:
      {         

 	  navigator.clipboard.writeText('"' + stringtemp + '"');

      }
      break;


      case QuotesToCText2:
      {         

 	  navigator.clipboard.writeText(AddQuotesToEachWord());

      }
      break;


      case ReverseString:
      {         

 	  navigator.clipboard.writeText(reverse(stringtemp));

      }
      break;


      case RemoveWS:
      {         

 	  navigator.clipboard.writeText(RemoveSpaces(stringtemp));

      }
      break;


      case DTStrLocal:
      {         

 	  navigator.clipboard.writeText(MonthDayYear(stringtemp));

      }
      break;

  }
});


function logTabs(temp) {
  // tabs[0].url requires the `tabs` permission or a matching host permission.
  
  var str = (new URL(temp)).hostname;

  //console.log(tabs[0].url);

  //console.log(str);

  str = str.replace("https://", "");
		  
  str = str.replace("http://", "");
		  
  str = str.replace("www.", "");
 
  CTabURL = "@" + str;

}



function MonthDayYear(str)
{
    try
    {

        str = remove_accents(str);


	var temp = str.toLowerCase().replace(/\./g, '').replace("and", '-').replace('&', '-');

        temp = temp.replace(/\|/g, '').replace(/\+/g, ' - ').replace(/\//g, ' - ').replace(new RegExp("of", "gi"), '');

        temp = temp.replace(/from|until/gi, '-').replace(/the/gi, '');



        const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
   
        const monthSmall = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

        const numAdd = ["th", "rd", "nd", "st"];

     
        const DayNames = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

        const DayNamesSmall = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];



	// const date = new Date(2009, 10, 10);  // 2009-11-10
	// const month = date.toLocaleString('default', { month: 'long' });

        // ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']


       var day = "", month = "", year = "";

       var SmallMonth = 0;

       
       for (var i = 0; i < monthNames.length; i++)
       {
       	    if (temp.search(monthNames[i].toLowerCase()) != -1)
            {
		month = monthNames[i];

                break;
	    }
       }

       if (month == "")
       {
           for (var i = 0; i < monthSmall.length; i++)
       	   {
       	    	if (temp.search(monthSmall[i].toLowerCase()) != -1)
         	{
                     month = monthNames[i];
                     
                     SmallMonth = 1;

                     break;
	        }
       	   }	
       }

       
       if (month == "")
	   return str;


       var mcnt = temp.split(month.toLowerCase()).length - 1;

       
       if (mcnt > 1)
       {

        // replace two years & two commas & two months

       }

       
       if (SmallMonth == 0)
	   temp = temp.replace(month.toLowerCase(), '').replace(/\s/g,'').trim();
       else
           temp = temp.replace(month.substring(0, 3).toLowerCase(), '').replace(/\s/g,'').trim();



       // Comma is Before 'to'

       // Trim All First & Last Chars If it is Comma ( , )

       //  ,may ;  ,,,april 2, 2023,,,,



       // Remove Day Names

       for (var i = 0; i < DayNames.length; i++)   // /\./g, ''
       {
           temp = temp.replace(new RegExp(DayNames[i].toLowerCase(), "gi"), '');

 	   temp = temp.replace(new RegExp(DayNamesSmall[i].toLowerCase(), "gi"), '');
       } 



       // Remove Num Add

       for (var i = 0; i < numAdd.length; i++)   // /\./g, ''
       {
           if (temp.includes("august"))
	   {
                temp = temp.replace(new RegExp("august", "gi"), "#MonName#");	

		temp = temp.replace(new RegExp(numAdd[i], "gi"), '');	

                temp = temp.replace(new RegExp("#MonName#", "gi"), "august");	
           }
	   else
	   {
	   	temp = temp.replace(new RegExp(numAdd[i], "gi"), '');
           }

           //temp = temp.replace(/th|rd|nd|st/gi, '');
       }    
 
       
       
       if (temp.indexOf(',') == -1)  // No ','
       {            
            year = temp.substring(temp.length - 4);
     
            if (!yearValidation(year))
	   	return str;

 
            day = temp.replace(year, '');
      

            if (day.search("to") != -1)           // "to" is present
	   	day = day.replace("to", " - ");
       	    else
            {
		day = day.replace('-', " - ");

                day = day.replace('�', " - ").replace('�', " - ");

            }

 
            // alert(day + " ==== " + month);  // 26 - 7july


            day = CheckDayForMonth(day, monthNames, monthSmall);

  
            return month + " " + day + ", " + year;
       }


       var ptr = temp.split(',')


       if (ptr.length == 0)
	   return str; 



       day = ptr[0].toLowerCase();

       year = ptr[1].trim();


       if (!yearValidation(year))
	   return str;
 

       if (day.search("to") != -1)
	   day = day.replace("to", " - ");
       else
       {
	   day = day.replace('-', ' - ');

           day = day.replace('�', " - ").replace('�', " - ");

       }

       

       day = CheckDayForMonth(day, monthNames, monthSmall);


     
       return month + " " + day + ", " + year;


    }
    catch(err)
    {
			
    }

    return str;
}


function CheckDayForMonth(day, monthNames, monthSmall)
{
    try
    {
       if (day.indexOf('-') == -1)  // No '-'
       {
	   return day;	
       }

       var mnth = "", temp = "";


       for (var i = 0; i < monthNames.length; i++)
       {
       	    if (day.search(monthNames[i].toLowerCase()) != -1)
            {
		//alert(day + " ======= " + monthNames[i]); // 26 - 7july
            
                // replace(new RegExp(numAdd[i], "gi"), ''); 

                // mnth = day.replace(new RegExp(monthNames[i], "gi"), '');
             
                mnth = monthNames[i];

                break;
	    }
       }


       if (mnth == "")
       {
           for (var i = 0; i < monthSmall.length; i++)
       	   {
       	    	if (day.search(monthSmall[i].toLowerCase()) != -1)
         	{
                     mnth = monthNames[i];
       
                     day = day.replace(monthSmall[i].toLowerCase(), mnth);

                     break;
	        }
       	   }	
       }


       if (mnth == "")
         return day;



       temp = day.replace(/\s/g,'').trim().split('-');



       return temp[0] + " - " + mnth + " " + temp[1].replace(new RegExp(mnth, "gi"), '');

    }
    catch(err)
    {
			
    }

    return day;
}


function yearValidation(year) 
{

  var text = /^[0-9]+$/;

   if (year != 0)
   {
        if ((year != "") && (!text.test(year))) 
        {
            //alert("Please Enter Numeric Values Only");
            return false;
        }

        if (year.length != 4) 
        {
            //alert("Year is not proper. Please check");
            return false;
        }

        var current_year = new Date().getFullYear();

        if ((year < 1000) || (year > 2999))
        {
            //alert("Year should be in range 1920 to current year");
            return false;
        }

        return true;

    } 
}


function remove_accents(strnw) 
{
    return strnw.normalize("NFD").replace(/[\u0300-\u036f]/g, "")
}


function RemoveSpaces(str)
  {
     try
     {
  	  	return str.replace(/\s/g,'').trim();
     }
     catch
     { }
     
     return str;
  }


function reverse(s){
    return [...s].reverse().join("");
}


function AddQuotesToEachWord()
{

    if (stringtemp.indexOf(" ") == -1)
	return '"' + stringtemp + '"';

    var s = stringtemp.split(" ");

    if (s.length > 0)
    {
	var str = "";

	for (let i = 0; i < s.length; i++) 
	{
		if (i == (s.length - 1))
			str += '"' + s[i] + '"';
		else	
			str += '"' + s[i] + '"' + " ";
	}

	return str;
    }

    return '"' + stringtemp + '"';

}


function GetFirstName()
{

    if (stringtemp.indexOf(" ") == -1)
	return "";

    var s = stringtemp.split(" ");

    if (s.length > 0)
    {
	return s[0];
    }

    return "";
}


function GetLastName()
{
    if (stringtemp.indexOf(" ") == -1)
	return "";

    var s = stringtemp.split(" ");

    if (s.length > 1)
    {
	return s[1];
    }

    return "";

}


function CommonActions2(LocalURL, LocalIndex, semail)
{
  let str = (new URL(LocalURL)).hostname.toLowerCase();
  
  
  // Check For Email
	
	if (LocalURL.indexOf("://") == -1)
	{
		str = LocalURL;
		
		str = str.replace("mailto:", "");
		
		var s = str.split("@")
		
		if (s.length > 1)
		{
			str = s[1];
						
			if (str.indexOf("?", 0) != -1)
				str = str.substring(0, str.indexOf("?", 0));
		}
	}
	else
	{
	  str = str.replace("https://", "");

	  str = str.replace("http://", "");
	  
	  str = str.replace("www.", "");

	}
	

   let str2 = str;

 
   str = "https://www.google.com/search?q=" + '"' + semail + "@" + str + '"'; 
 
	  
  browser.tabs.create({
	  active: true,
	  index: LocalIndex + 1,
	  url: str
	});	 
	

   try {  navigator.clipboard.writeText(semail + "@" + str2);  }
   
   catch { }

  return;
}

function CommonActions(LocalURL, LocalIndex, flag)
{
  let str = (new URL(LocalURL)).hostname.toLowerCase();
  
  
  // Check For Email
	
	if (LocalURL.indexOf("://") == -1)
	{
		str = LocalURL;
		
		str = str.replace("mailto:", "");
		
		var s = str.split("@")
		
		if (s.length > 1)
		{
			str = s[1];
						
			if (str.indexOf("?", 0) != -1)
				str = str.substring(0, str.indexOf("?", 0));
		}
	}
	else
	{
	  str = str.replace("https://", "");

	  str = str.replace("http://", "");
	  
	  str = str.replace("www.", "");

	}
	
 
  if (flag == 0)
  {	  str = "https://www.google.com/search?q=" + "site:" + str + " " + stringtemp;  }
  else
  {        str = "https://www.google.com/search?q=" + "site:" + str + " " + '"' + stringtemp + '"'; }

	  
  browser.tabs.create({
	  active: true,
	  index: LocalIndex + 1,
	  url: str
	});	 
	
  return;
}


function onError(error) {
  console.error(`Error: ${error}`);
}

browser.tabs
  .query({ currentWindow: true, active: true })
  .then(logTabs, onError);


browser.menus.onShown.addListener(info => {
 
	navigator.clipboard.readText().then(ss => stringtemp = ss);
	
	
});

	